# Landing Page Project

## Table of Contents

- [Instructions](#instructions)
- [Basic Informations]

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.

## Basic Informations

The projict is about creating a multi-section landing page with dynamically updating navigational menu using javascript.

Project folder contains four files:

- README.md
- index.html
- style.css
- app.js

I did some research to find out how am I going to implement the "Scroll to section" mechanism and I found some very useful information on https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
