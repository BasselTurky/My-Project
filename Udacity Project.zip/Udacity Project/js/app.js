/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

//----------------------------------------------------

/*
 *Define Global Variables.
 */

const navbarMenu = document.querySelector("#navbar__list");

/*
 *Create Navigation Menu content.
 */

// Add all of the sections in a single array to be able to loop through it
const selectAllSections = document.querySelectorAll("section");

// Add X number of lists in the Menu to match the number of sections in the DOM
for (let i = 0; i < selectAllSections.length; i++) {
  // Create a <li> element
  let list = document.createElement("li");

  // Append list to the Menu
  navbarMenu.appendChild(list);

  // Create a button
  const button = document.createElement("button");
  // Give the button a class "menu__link" for styling and to set Scroll Event to it
  button.setAttribute("class", "menu__link");

  /* Add text in each button to represent the section it leads to, 
   or a default value of section name isn't provided in "data-nav" */
  if (selectAllSections[i].getAttribute("data-nav") == undefined) {
    button.textContent = "New Section";
  } else {
    button.textContent = selectAllSections[i].getAttribute("data-nav");
  }
  // Finally add the button to list
  list.appendChild(button);
}

/*
 *Begin Events
 */

// Add all buttons with class "menu__link" to a single array
const selectAllButtons = document.querySelectorAll(".menu__link");

// Loop through the array and assign an event listener to each button
for (let i = 0; i < selectAllButtons.length; i++) {
  selectAllButtons[i].addEventListener("click", () => {
    selectAllSections[i].scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  });
}

/*
 * Set sections as active
 */

const testsect = document.querySelector(".test");
window.addEventListener("scroll", function () {
  for (let i = 0; i < selectAllSections.length; i++) {
    /* For every section, set class "active" if the section is in browser view 
       and remove the class if it's not.*/
    if (
      selectAllSections[i].getBoundingClientRect().bottom <
        window.innerHeight &&
      selectAllSections[i].getBoundingClientRect().top > 0
    ) {
      selectAllSections[i].classList.add("your-active-class");
    } else {
      selectAllSections[i].classList.remove("your-active-class");
    }
    /* Check if a section has "active" class 
       then add class "inView" class the linked button*/
    if (selectAllSections[i].classList.contains("your-active-class")) {
      selectAllButtons[i].classList.add("inView");
    } else {
      selectAllButtons[i].classList.remove("inView");
    }
  }
});

/*
 * Scroll Up button
 */
const upDiv = document.createElement("div");
const navi = document.querySelector(".navbar__menu");
navi.setAttribute("class", "navbar__menu navbar__menu__new");
navi.insertAdjacentElement("afterbegin", upDiv);

const buttonUp = document.createElement("button");
buttonUp.setAttribute("class", "buttonUp");
buttonUp.textContent = "UP";
upDiv.appendChild(buttonUp);

const headerUp = document.querySelector("h1");
buttonUp.addEventListener("click", () => {
  headerUp.scrollIntoView({ behavior: "smooth", block: "center" });
});
